# HUGO KID — Learn, Play, Grow

Mfumo wa elimu wa HUGO TECH kwa watoto wa miaka 3–12, wazazi, walimu na shule.
Code moja inatumika kwa sehemu tatu:

1. **Programu ya Android (APK)**: watoto na wazazi (na walimu wakipenda).
2. **Web app**: shule, walimu, wazazi na HUGO TECH. Inafunguka kwenye kompyuta, tablet, Android na iPhone.
3. **Server**: akaunti, shule, homework, alama, ujumbe, simu za Pamoja. Haina maktaba za nje, inahitaji Node 22 tu.

---

## A. Kuweka server kwenye Railway (mara moja)

1. Pakia mradi huu wote kwenye GitHub (repository moja), kama ilivyoelezwa sehemu B.
2. Railway: **New Project → Deploy from GitHub repo**, chagua repository hii.
3. Hakikisha faili `railpack.json` lipo kwenye repository (linaiambia Railway iendeshe server ya Node, si kujenga Android). Railway itaendesha `npm start` yenyewe.
4. **Volume (lazima, ili data isipotee):** kwenye service, fungua **Settings → Volumes → Add Volume**, mount path: `/data`.
5. **Variables:** ongeza
   - `DATA_DIR` = `/data`
   - (si lazima) `ADMIN_EMAIL` na `ADMIN_PASSWORD` kwa akaunti ya HUGO TECH. Usipoweka, ni `admin@hugotech.co.tz` / `HugoKid@2026`.
6. **Settings → Networking → Generate Domain**. Utapata anwani kama `https://hugo-kid-production.up.railway.app`.
7. Fungua anwani hiyo kwenye browser na uingie kwa akaunti ya HUGO TECH. Utalazimika kubadilisha nenosiri mara ya kwanza.
8. Kwenye dashboard ya HUGO TECH:
   - **AI ya server**: chagua Gemini, Claude au ChatGPT na uweke API key. Inatumika kusahihisha, msaidizi wa mwalimu na ripoti za wazazi.
   - **Bei** na **maelekezo ya kulipa** (mfano Lipa Namba ya M-Pesa).

Server inajiweka yenyewe mara ya kwanza (inaunda hifadhidata na akaunti ya HUGO TECH). Hakuna ukurasa wa install.

## B. Kupata APK (GitHub Actions)

1. Kabla ya kupakia, fungua `app/src/main/assets/www/js/net.js` na ubadilishe mstari huu uwe anwani yako ya Railway:
   `const HK_SERVER_DEFAULT = 'https://smartmark.space';`
   (Mtumiaji haoni anwani hii; imewekwa ndani ya app.)
2. GitHub: tengeneza repository mpya (Private), kisha **Add file → Upload files**, na upakie VITU VYOTE vilivyo ndani ya folda `hugo-kid`.
   Hakikisha folda `.github` imepakiwa. Kwenye Mac au Windows huenda imefichwa: washa "show hidden files".
3. **Commit changes**, kisha fungua tab ya **Actions**. Build ya "Build HUGO KID APK" inachukua dakika 3–6.
4. Ikimaliza, fungua build hiyo na upakue **HUGO-KID-APK** chini ya Artifacts. Ndani yake kuna `HUGO-KID.apk`.

Kila ukibadilisha faili kwenye GitHub, APK mpya inajengwa, na Railway inasasisha server yenyewe.

## C. iPhone

Kwa sasa iPhone inatumia **web app**: fungua anwani ya Railway kwenye Safari, kisha **Share → Add to Home Screen**. Inafanya kazi kama programu.
App ya iPhone kwenye App Store inahitaji kompyuta ya Mac (Xcode) na akaunti ya Apple Developer (USD 99 kwa mwaka). Code hii inaweza kufungwa kama app ya iPhone baadaye.

## D. Watumiaji na wanachoona

| Akaunti | Anajisajili vipi | Anaona |
|---|---|---|
| **HUGO TECH** (msimamizi mkuu) | Inaundwa yenyewe | Shule zote, takwimu, ankara na malipo, bei, AI ya server, kusimamisha shule |
| **Mkuu wa shule** | Web app → "Shule au mwalimu" → Jisajili (Shule) | Takwimu za shule, madarasa, walimu, wanafunzi, misimbo ya wazazi, wazazi wa shule, matangazo, masomo, ujumbe, malipo |
| **Mwalimu binafsi / Tuition** | Web app → "Shule au mwalimu" → Jisajili (Mwalimu binafsi) | Kama mkuu wa shule, na yeye ndiye mwalimu wa madarasa yake |
| **Mwalimu** | Mkuu wa shule anamwongeza na kumpa nenosiri la muda | Madarasa yake, homework (karatasi, quiz, kazi ya wazi), kusahihisha, msaidizi wa AI, mahudhurio, ripoti, ujumbe na wazazi |
| **Mzazi** | Programu au web → "Mimi ni mzazi" | Watoto wake, ripoti, alama, deadline, mahudhurio, ripoti ya Nuru, ujumbe na mwalimu, matangazo, marafiki wa mtoto, Learning Mode, malipo |
| **Mtoto** | Mzazi anamsajili | Home inayolingana na umri na uwezo wake |

**Kuunganisha mtoto na shule:** mwalimu au mkuu wa shule anaongeza wanafunzi kwenye darasa, na kila mmoja anapata msimbo (anaweza kuchapisha misimbo yote). Mzazi anaweka msimbo kwenye **Eneo la Mzazi → Shule**.

## E. Modi za mtoto (zinabadilika zenyewe)

| Modi | Umri | Muonekano |
|---|---|---|
| Mdogo | 3–4 | Picha kubwa, sauti kwa kila kitu, "Gusa tembo", rangi, wanyama, namba, maumbo |
| Anaanza kusoma | 5–6 | Picha pamoja na maandishi, herufi A–Z kwa sauti, kurudia kwa sauti |
| Mvumbuzi | 7–9 | Misheni za leo, Ramani ya Safari, homework, quiz, medali |
| Mvumbuzi Mkuu | 10–12 | Studio ya AI (miradi), changamoto na coding, ripoti ya maendeleo, utafiti na Nuru |

Baada ya kusajiliwa, mtoto anafanya **kipimo cha uwezo** cha dakika 5, na kinamweka kwenye kiwango kinachomfaa (si umri peke yake). Nuru anaendelea kufuatilia matokeo ya michezo na masomo, na kiwango kinapanda au kushuka kadri mtoto anavyokua.
Mahitaji maalum: kuona hafifu (maandishi makubwa), kusikia hafifu (maandishi ya kila sauti), dyslexia (nafasi kubwa kati ya herufi), umakini mfupi.

## F. Muundo wa mafaili

```
server/                  Server (Node 22, bila maktaba za nje)
  server.js              inaanzisha server, web app, faili na WebSocket
  db.js                  hifadhidata (SQLite iliyo ndani ya Node)
  auth.js                nenosiri, tokeni, akaunti ya HUGO TECH
  router.js              msingi wa API na ruhusa
  routes-core.js         akaunti, shule, madarasa, walimu, wanafunzi, wazazi
  routes-homework.js     homework, faili, kusahihisha (AI + mwalimu), matokeo
  routes-family.js       watoto, misimbo, marafiki
  routes-school.js       masomo, mahudhurio, matangazo, ujumbe, ripoti, malipo
  routes-admin.js        takwimu za HUGO TECH
  ai.js                  AI ya server
  hub.js                 WebSocket: taarifa za papo hapo, simu, kucheza pamoja
app/src/main/assets/www/ Programu (simu na web)
  js/account.js          karibu, kuingia, kujisajili
  js/modes.js            modi za umri, kipimo cha uwezo, michezo ya "Gusa"
  js/home.js             home ya mtoto kwa kila modi, ramani ya safari, ripoti
  js/school.js           dashboards za shule na mwalimu, kusahihisha
  js/schoolhw.js         homework za mwalimu upande wa mtoto
  js/online.js           mzazi mtandaoni, HUGO TECH
  js/together.js         Pamoja: marafiki, simu, kucheza pamoja
  js/i18n.js             Lugha ya programu (Kiswahili / English) na kitufe cha SW | EN
  js/i18n-en.js          Tafsiri ya Kiingereza ya maandishi yote
  ... (michezo, masomo, AI, Learning Mode, n.k.)
app/src/main/java/...    Android (Kotlin): kamera, sauti, Learning Mode
```

## G. Mambo ya kukamilisha kabla ya kuuza

- **Malipo ya moja kwa moja (M-Pesa, Tigo Pesa, Airtel Money)**: kwa sasa shule au mzazi analipa kwa Lipa Namba, anaweka namba ya muamala, na HUGO TECH inathibitisha kwenye dashboard. Malipo ya moja kwa moja yanahitaji akaunti ya mtoa huduma (mfano Selcom, AzamPay au ClickPesa), kisha yanaunganishwa hapa.
- **Maudhui ya imani** yakaguliwe na ustadh na mchungaji.
- **Masharti na Sera ya Faragha** yakaguliwe na mwanasheria, na HUGO TECH ijisajili kwa Tume ya Ulinzi wa Taarifa Binafsi (PDPC).
- **Simu za video** zinatumia STUN ya bure. Kwenye mitandao michache inayozuia simu za moja kwa moja, utahitaji TURN server (mfano ya Twilio au Metered).
